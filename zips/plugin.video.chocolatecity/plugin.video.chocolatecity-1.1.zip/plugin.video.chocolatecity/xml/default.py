# The documentation written by Voinage was used as a template for this addon
# https://wiki.xbmc.org/?title=HOW-TO_write_plugins_for_XBMC
#
# This addon is licensed with the GNU Public License, and can freely be modified
# https://www.gnu.org/licenses/gpl-2.0.html

import urllib, urllib2, re, sys, xbmcplugin, xbmcgui, xbmc

BASE_URL = 'https://www.porntrex.com/'


def CATEGORIES():
    addDir("[COLOR red]H[/COLOR][COLOR white]ome[/COLOR]", 'https://www.porntrex.com/', 1, "https://www.shesfreaky.com/templates/shesfreakyv3/images/logo.png")
    addDir("[COLOR red]R[/COLOR][COLOR white]ecent[/COLOR]", "https://www.porntrex.com/latest-updates/", 1, "https://www.shesfreaky.com/templates/shesfreakyv3/images/logo.png")
    addDir("[COLOR red]V[/COLOR][COLOR white]iewed[/COLOR]", "https://www.porntrex.com/most-popular/", 1, "https://www.shesfreaky.com/templates/shesfreakyv3/images/logo.png")
    addDir("[COLOR red]R[/COLOR][COLOR white]ated[/COLOR]", "https://www.porntrex.com/top-rated/", 1, "https://www.shesfreaky.com/templates/shesfreakyv3/images/logo.png")
    #  addDir("[COLOR red]Tags[/COLOR][COLOR white] Video[/COLOR]", 'https://www.shesfreaky.com/tags', 1, "https://www.shesfreaky.com/templates/shesfreakyv3/images/logo.png")
    # addDir("[COLOR red]P[/COLOR][COLOR white]laylists[/COLOR]", 'https://www.shesfreaky.com/playlists/', 3, "https://www.shesfreaky.com/templates/shesfreakyv3/images/logo.png")
    
    link = read_url('https://www.porntrex.com/categories/')
    match = re.compile('<a class="item" href="([^"]+)" title="([^"]+)">',re.DOTALL).findall(link)
    for url, title in match:
        url = url + "page1.html"
        addDir(title, url, 1,"https://www.shesfreaky.com/templates/shesfreakyv3/images/logo.png")
        matchpage = re.compile('pagination".+?<span>.+?</span><a href="([^"]+)">.+?</a>').findall(link)
        if matchpage:
            addDir('Next Page', BASE_URL + '' + matchpage[0], 1, '')
        
        
        
  #pllink = read_url('https://www.shesfreaky.com/playlists/')
    match = re.compile('<div class="playlist-play"><p><a href="([^"]+).+?<em title="([^"]+)">.+?</em>',re.DOTALL).findall(pllink)
    for url, title in match:
        addDir(title, url, 1,"https://www.shesfreaky.com/templates/shesfreakyv3/images/logo.png")


def _get_keyboard(default="", heading="", hidden=False):
    """ shows a keyboard and returns a value """
    keyboard = xbmc.Keyboard(default, heading, hidden)
    keyboard.doModal()
    if keyboard.isConfirmed():
        return unicode(keyboard.getText(), "utf-8")
    return default


def INDEX(url):
    addDir('[COLOR red]Search[/COLOR]','https://www.shesfreaky.com/search/([^"]+)',4,'')
    addDir('Home', '', None, '')
    # url: https://www.shesfreaky.com/channels/
    add_next(url)
    link = read_url(url)
    match = re.compile('<a href="([^"]+)" title="([^"]+)".+?<img class="thumb" src="([^"]+)" alt=".+?"/> >'
,re.DOTALL).findall(link)
    for url,name,thumbnail  in match:
        addDownLink(name , url, 2, "https:" + thumbnail)
    
   
#def PLINDEX(url):
    addDir('[COLOR red]Search[/COLOR]','https://www.shesfreaky.com/search/videos/([^"]+)/page1.html',4,'')
    addDir('Home', '', None, '')
    # url: https://www.shesfreaky.com/channels/
    # add_next(url)
    pllink = read_url(url)
    match = re.compile('<div class="playlist-play"><p><a href="([^"]+).+?data-src="([^"]+)" alt="([^"]+)" />">.+?<div class="playlist-count"><span>([^"]+)</span>videos</div>'
,re.DOTALL).findall(pllink)
    for url, thumbnail, name, length in match:
        addDownLink(name + ' ' + length, url, 2, "https:" + thumbnail)        
 
def VIDEOLINKS(url, name):
    link = read_url(url)
    pllink = read_url(url)
    match = re.compile('video_alt_url2: \'(.+?)\',').findall(link)
    for url in match:
        listitem = xbmcgui.ListItem(name)
        listitem.setArt({ 'poster': 'thumb'})
        iconimage = xbmc.getInfoImage("ListItem.Thumb")
        listitem = xbmcgui.ListItem(name, iconImage="DefaultVideo.png", thumbnailImage=iconimage)
        listitem.setInfo('video', {'Title': name, 'Genre': 'Porn'})
        print "Playing: " +  url
        xbmc.Player().play(url, listitem)

def SEARCHVIDEOS(url):
        searchUrl = url
        vq = _get_keyboard(heading="Enter the query")
        # if blank or the user cancelled the keyboard, return
        if (not vq): return False, 0
        # we need to set the title to our query
        title = re.sub('[^0-9a-zA-Z]+', '-', vq)
        searchUrl = searchUrl + title
        xbmc.log("Searching URL: " + searchUrl)
        INDEX(searchUrl)


def add_next(url):
    match = re.compile('(\d+)$').findall(url)
    if match:
        page_number = int(match[0])
        page_number+=1 # This will 404 eventually
        category_url=url.split('=')[0]
        next_url = category_url + '=' + str(page_number)
        addDir("Next", next_url, 1, "")

def read_url(url):
    req = urllib2.Request(url)
    req.add_header('User-Agent',
                   'Mozilla/5.0 (Windows; U; Windows NT 5.1; en-GB;'
                   ' rv:1.9.0.3) Gecko/2008092417 Firefox/3.0.3')
    response = urllib2.urlopen(req)
    link = response.read()
    response.close()
    return link

def get_params():
    param = []
    paramstring = sys.argv[2]
    if len(paramstring) >= 2:
        params = sys.argv[2]
        cleanedparams = params.replace('?', '')
        if (params[len(params)-1] == '/'):
            params = params[0:len(params)-2]
        pairsofparams = cleanedparams.split('&')
        param = {}
        for i in range(len(pairsofparams)):
            splitparams = {}
            splitparams = pairsofparams[i].split('=')
            if (len(splitparams)) == 2:
                param[splitparams[0]] = splitparams[1]

    return param

def addDownLink(name, url, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + \
        str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultVideo.png",
                           thumbnailImage=iconimage)
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u,
                                     listitem=liz, isFolder=False)
    return ok

def addDir(name, url, mode, iconimage):
    u = sys.argv[0] + "?url=" + urllib.quote_plus(url) + "&mode=" + \
        str(mode) + "&name=" + urllib.quote_plus(name)
    ok = True
    liz = xbmcgui.ListItem(name, iconImage="DefaultFolder.png",
                           thumbnailImage=iconimage)
    liz.setInfo( type="Video", infoLabels={ "Title": name } )
    ok = xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u,
                                     listitem=liz, isFolder=True)
    return ok


topparams = get_params()
topurl = None
topname = None
topmode = None

try:
    topurl = urllib.unquote_plus(topparams["url"])
except:
    pass
try:
    topname = urllib.unquote_plus(topparams["name"])
except:
    pass
try:
    topmode = int(topparams["mode"])
except:
    pass

print "Mode: " + str(topmode)
print "URL: " + str(topurl)
print "Name: " + str(topname)

if topmode == None or topurl == None or len(topurl)<1:
    print ""
    CATEGORIES()

elif topmode == 1:
    print "" + topurl
    INDEX(topurl)

elif topmode == 2:
    print "" + topurl
    VIDEOLINKS(topurl, topname)

elif topmode == 3:
    print "" + topurl
    TAGINDEX(topurl)

elif topmode == 4:
        SEARCHVIDEOS(topurl)        

xbmcplugin.endOfDirectory(int(sys.argv[1]))